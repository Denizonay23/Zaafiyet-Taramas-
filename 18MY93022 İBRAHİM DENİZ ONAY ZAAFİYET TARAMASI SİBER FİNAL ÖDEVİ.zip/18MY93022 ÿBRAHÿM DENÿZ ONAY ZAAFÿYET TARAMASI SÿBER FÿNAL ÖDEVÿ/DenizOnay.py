import os

os.system("nmap -A -sC -p80 convertio.co reddit.com -oX DenizOnay.xml")

#KAYNAK : https://www.metingerdan.com/xss-saldirilari/  && https://www.youtube.com/

#-A Detail Scan

#-sC : All Scripts

#-p : Port

#cmd vasıtası ile nmap aracını kullanarak ilgili siteler hakkında bilgiler ediniyoruz.

#Parametrelerin açıklaması yukarıda detaylı yazışmıştır